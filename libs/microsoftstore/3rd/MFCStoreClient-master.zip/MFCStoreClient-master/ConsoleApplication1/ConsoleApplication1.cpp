// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#include "pch.h"
#include <iostream>
#include <conio.h>

int main()
{
    std::cout << "Hello World!\n";
    std::cout << "Press any key to exit...\n";
    _getch();
}
