// SPDX-FileCopyrightText: Olivier Cléro <oclero@hotmail.com>
// SPDX-License-Identifier: MIT

#include <oclero/qlementine/animation/WidgetAnimator.hpp>

namespace oclero::qlementine {
// TODO supprimer ce fichier si inutile
} // namespace oclero::qlementine
