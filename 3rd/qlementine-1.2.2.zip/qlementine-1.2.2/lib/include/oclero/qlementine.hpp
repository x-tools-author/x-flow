// SPDX-FileCopyrightText: Olivier Cléro <oclero@hotmail.com>
// SPDX-License-Identifier: MIT

#pragma once

#include <oclero/qlementine/style/ThemeManager.hpp>
#include <oclero/qlementine/style/QlementineStyle.hpp>
