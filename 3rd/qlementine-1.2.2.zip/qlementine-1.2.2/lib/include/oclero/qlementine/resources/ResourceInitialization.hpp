// SPDX-FileCopyrightText: Olivier Cléro <oclero@hotmail.com>
// SPDX-License-Identifier: MIT

#pragma once

namespace oclero::qlementine::resources {
void initializeResources();
} // namespace oclero::qlementine::resources
